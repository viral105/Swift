//
//  Assets.swift
//  OSHSwift
//
//  Created by Viral Narshana on 7/5/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit
import CoreData

@objc(Assets)

class Assets: NSManagedObject {
    // Attributes
    @NSManaged var modifiedDate: String
    @NSManaged var createdDate: String
    @NSManaged var timeStamp: String
    @NSManaged var mostViewedCounter: String
    @NSManaged var isFavourite: String
    @NSManaged var campaignId: String
    @NSManaged var downloadStatus: String
    @NSManaged var userId: String
    @NSManaged var contentId: String
    @NSManaged var companyId: String
    @NSManaged var fileName: String
    @NSManaged var fileDescription: String
    @NSManaged var fileKeyword: String
}
