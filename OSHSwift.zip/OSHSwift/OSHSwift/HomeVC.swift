//
//  HomeVC.swift
//  OSHSwift
//
//  Created by Viral Narshana on 7/5/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit
import Alamofire
import MagicalRecord
class HomeVC: UIViewController {

    var arrCampaign: [Campaign]!
    var arrAssets = [Array<Any>]()
    var arrAllAssets = [Assets]()
    var cntDownloadFile = 0
    var downloadProgress = 0.0
    var isFileDownloadGoingOn = true
    var cvcell: HomeVcCvAssetsCell!
    var downloadInProgressCvCellIpath: IndexPath!
    
    @IBOutlet var tblViewMain: UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: false)
        self.automaticallyAdjustsScrollViewInsets = false
        // Do any additional setup after loading the view.
/*        let obj = Campaign.mr_createEntity()! as Campaign
        obj.campaignCode = "asdf"
        obj.campaignCost = "4554"
        obj.campaignId = "af54545"
        
        NSManagedObjectContext.mr_default().mr_saveToPersistentStore(completion: nil)
*/
        let key = UserDefaults.standard.object(forKey: "isFirstTimeLogin") as? Bool
        
        if !key! {
            print("Already login")
            
            self.getLocalData()
            
        }
        else {
            //self.syncData(sender: "")
        }
        
        for view in self.view.subviews {
            if view .isKind(of: UIButton().classForCoder) {
                print("uibutton found")
            }
            else if view .isKind(of: UILabel().classForCoder) {
                print("uilabel found")
            }
            else {
                print("not button or label")
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func getLocalData() {
        self.arrCampaign = Campaign.mr_findAllSorted(by: "campaignId", ascending: true) as! [Campaign]!
        
        for index in 0...self.arrCampaign.count-1 {
            
            let predicate = NSPredicate(format: "campaignId == %@", self.arrCampaign[index].campaignId!)
            
            //let fetchRequest = Assets.mr_requestAll(with: predicate)
            let fetch = Assets.mr_requestAllSorted(by: "fileName", ascending: true, with: predicate)
            let result = Assets.mr_executeFetchRequest(fetch) as! [Assets]!
            
            self.arrAssets.append(result!)
            
            self.tblViewMain?.reloadData()
        }
    }
    func updateDownloadProgress() {
        if self.cntDownloadFile >= self.arrAllAssets.count {
            return
        }
        if Int(self.downloadProgress) == 1 {
            
            self.downloadProgress = 0.0
            self.cvcell.pViewDownload?.progress = 0.0
            
            self.updateDb(objAss: self.arrAllAssets[self.cntDownloadFile])
            self.isFileDownloadGoingOn = true
            self.cntDownloadFile += 1
            //self.updateDownloadProgress()
            self.perform(#selector(updateDownloadProgress), with: nil, afterDelay: 0.1)
            return
        }
        if self.isFileDownloadGoingOn {
            
            let objAss = self.arrAllAssets[self.cntDownloadFile]
            
            for i in 0..<self.arrCampaign.count {
                let obj = self.arrAssets[i]
                for j in 0..<obj.count {
                    let objAsset = obj[j] as! Assets
                    
                    if objAss.contentId == objAsset.contentId {
                        if objAss.isDownloaded == "false" {
                            let indexPath: IndexPath = IndexPath(row: 0, section: i)
                            let cell = self.tblViewMain?.cellForRow(at: indexPath) as! HomeVcTblCell
                            self.downloadInProgressCvCellIpath = IndexPath(item:j, section: 0)
                            if cell.cvAssets.indexPathsForVisibleItems.contains(self.downloadInProgressCvCellIpath) {
                                self.cvcell = cell.cvAssets.cellForItem(at: self.downloadInProgressCvCellIpath) as! HomeVcCvAssetsCell
                                self.cvcell.pViewDownload?.progress = Float(self.downloadProgress)
                                
                            }
                            cell.cvAssets.scrollToItem(at: self.downloadInProgressCvCellIpath, at: .centeredHorizontally, animated: true)
                            self.isFileDownloadGoingOn = false
                            
                            
                        }
                        else {
                            print("file already downloaded")
                            self.isFileDownloadGoingOn = false
                            self.downloadProgress = 0.9
                        }
                        break
                        
                    }
                }
                if !self.isFileDownloadGoingOn {
                    break
                }
            }
        }
        else{
            if let ipath = (self.cvcell.superview as! UICollectionView).indexPath(for: self.cvcell) {
                if ipath == self.downloadInProgressCvCellIpath {
                    self.cvcell.pViewDownload?.progress = Float(self.downloadProgress)
                }
            }
        }
        
            //print(self.downloadProgress)
            self.downloadProgress += 0.1
            self.perform(#selector(self.updateDownloadProgress), with: nil, afterDelay: 0.01)

        
        //self.updateDownloadProgress()
    }
    
    func updateDb(objAss: Assets) {
        let predicate = NSPredicate(format: "contentId == %@", objAss.contentId!)
        let fetch = Assets.mr_requestAll(with: predicate)
        let result = Assets.mr_executeFetchRequest(fetch) as! [Assets]
        
        for index in 0..<result.count {
            let objTemp = result[index] 
            objTemp.isDownloaded = "true"
            let ind = self.arrAllAssets.index(of: objTemp)
            self.arrAllAssets[ind!] = objTemp
        }
        NSManagedObjectContext.mr_default().mr_saveToPersistentStore(completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func syncData(sender:Any) {
        let parameters: Parameters = [
            "CampignCompanyID": "1",
            "UserID": "c5bb22822f5f41eaabd8521143c637e6",
            "DeviceID": "test123asffsda",
            "Timestamp": "0"
        ]
        Alamofire.request("http://api.omnisaleshub.com/api/SyncData", method: .post, parameters: parameters).responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            
            if let json = response.result.value {
                //print("JSON: \(json)") // serialized json response
                let objJSON = json as! NSDictionary
                print(objJSON)
                self.insertIntoDB(objJson: json as! NSDictionary)
            }
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                //print("Data: \(utf8Text)") // original server data as UTF8 string
            }
        }
    }
    func insertIntoDB(objJson: NSDictionary) {
        
        let objCamp = objJson.value(forKey: "Campaigns") as! NSArray
        
        for index in 0...objCamp.count-1{
            print((objCamp[index] as AnyObject).value(forKey: "Assets") as! NSArray)
            
            let obj = Campaign.mr_createEntity()! as Campaign
            obj.campaignCode = (objCamp[index] as AnyObject).value(forKey: "CampaignCode") as? String
            obj.campaignCost = (objCamp[index] as AnyObject).value(forKey: "CampaignCost") as? String
            obj.campaignId = (objCamp[index] as AnyObject).value(forKey: "CampaignID") as? String
            obj.campaignName = (objCamp[index] as AnyObject).value(forKey: "CampaignName") as? String
            obj.campaignDesc = (objCamp[index] as AnyObject).value(forKey: "CampaignDescription") as? String
            obj.campaignType = (objCamp[index] as AnyObject).value(forKey: "CampaignType") as? String
            obj.campaignEndDate = (objCamp[index] as AnyObject).value(forKey: "CampaignEndDate") as? String
            obj.campaignParentId = (objCamp[index] as AnyObject).value(forKey: "CampaignParentID") as? String
            obj.campaignStartDate = (objCamp[index] as AnyObject).value(forKey: "CampaignStartDate") as? String
            obj.companyId = (objCamp[index] as AnyObject).value(forKey: "CampaignCompanyID") as? String
            //obj.userId = (objCamp[index] as AnyObject).value(forKey: "CampaignName") as? String
            
            
            for objAss in (objCamp[index] as AnyObject).value(forKey: "Assets") as! NSArray {
                print((objAss as! NSDictionary).value(forKey: "FileName")!)
                let obj = Assets.mr_createEntity()! as Assets
                obj.campaignId = (objAss as! NSDictionary).value(forKey: "CampaignID")! as? String
                obj.companyId = (objAss as! NSDictionary).value(forKey: "CompanyID")! as? String
                obj.contentId = (objAss as! NSDictionary).value(forKey: "ContentID")! as? String
                obj.createdDate = (objAss as! NSDictionary).value(forKey: "FileCreatedDate")! as? String
                obj.downloadStatus = "0"
                obj.fileDescription = (objAss as! NSDictionary).value(forKey: "FileDescription")! as? String
                obj.fileKeyword = (objAss as! NSDictionary).value(forKey: "FileKeyword")! as? String
                obj.fileName = (objAss as! NSDictionary).value(forKey: "FileName")! as? String
                obj.isDownloaded = "false"
                //obj.isFavourite = (objAss as! NSDictionary).value(forKey: "FileName")! as? String
                //obj.modifiedDate = (objAss as! NSDictionary).value(forKey: "FileModifiedDate")! as? String
                //obj.mostViewedCounter = (objAss as! NSDictionary).value(forKey: "FileName")! as? String
                //obj.timeStamp = (objAss as! NSDictionary).value(forKey: "FileName")! as? String
                obj.userId = (objAss as! NSDictionary).value(forKey: "FileName")! as? String
            }
            
        }
            NSManagedObjectContext.mr_default().mr_saveToPersistentStore(completion: nil)
            UserDefaults.standard.set(false, forKey: "isFirstTimeLogin")
            UserDefaults.standard.synchronize()
        self.getLocalData()
    }
    
    @IBAction func btnDownloadClicked() {
        for index in 0...self.arrCampaign.count-1 {
            let obj = self.arrAssets[index]
            for j in 0...obj.count-1 {
                let objAsset = obj[j] as! Assets
                if objAsset.isDownloaded == "false" {
                    self.arrAllAssets.append(objAsset)
                }
            }
        }
        //self.startDownload()
        if self.arrAllAssets.count != 0 {
            self.perform(#selector(updateDownloadProgress), with: nil, afterDelay: 0.5)
        }
        else{
            let alert = UIAlertController(title: "Alert", message: "No files to download", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    func startDownload() {
        let objAsset = self.arrAllAssets[self.cntDownloadFile]
        
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            /*var documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            
            // the name of the file here I kept is yourFileName with appended extension
            documentsURL.appendPathComponent("AssetFile"+objAsset.fileName!)
            */
            /*let paths = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
            let documentsDirectory: AnyObject = paths[0] as AnyObject
            let dataPath = documentsDirectory.appendingPathComponent("AssetFile")!
            let filepath = dataPath.appendingPathComponent(objAsset.fileName!)
            */
            let documentsPath1 = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
            let logsPath = documentsPath1.appendingPathComponent("AssetFile")
            let filepath = logsPath?.appendingPathComponent("3BA-Course-Outline-Sem1&2_2015-2016.doc")
            return (filepath!, [.removePreviousFile])
        }
        print(objAsset.fileName!)
/*        Alamofire.request("http://api.omnisaleshub.com/api/GetFile", method: .post, parameters: ["CompanyID":objAsset.companyId!, "ContentId":objAsset.contentId!, "FileName":objAsset.fileName!], encoding: JSONEncoding.default, headers: nil).downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
            print("Progress: \(progress.fractionCompleted)")
        }
            .validate { request, response, data in
                // Custom evaluation closure now includes data (allows you to parse data to dig out error messages if necessary)
                return .success
            }
            .responseJSON { response in
                debugPrint(response)
//                self.cntDownloadFile += 1
//                self.startDownload()
        }
*/

        
/*        Alamofire.download("http://api.omnisaleshub.com/api/GetFile", method: .post, parameters: ["CompanyID":objAsset.companyId!, "ContentId":objAsset.contentId!, "FileName":objAsset.fileName!], encoding: JSONEncoding.default, headers: nil, to: destination).downloadProgress(closure: { (progress) in
            //progress closure
            print(progress.fractionCompleted)
        }).response(completionHandler: { (DefaultDownloadResponse) in
            //here you able to access the DefaultDownloadResponse
            //result closure
            print(DefaultDownloadResponse.request!)
            
//            objAsset.downloadStatus = "1"
//            NSManagedObjectContext.mr_default().mr_saveToPersistentStore(completion: nil)
//            
//            self.cntDownloadFile += 1
//            self.startDownload()
        })
*/
        
        Alamofire.download("http://api.omnisaleshub.com/api/GetFile", method: .post, parameters: ["CompanyID":objAsset.companyId!, "ContentId":objAsset.contentId!, "FileName":"3BA-Course-Outline-Sem1&2_2015-2016.doc"], encoding: JSONEncoding.default, to: destination).downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
                print("Progress: \(progress.fractionCompleted)")
            }.validate { request, response, temporaryURL, destinationURL in
                // Custom evaluation closure now includes file URLs (allows you to parse out error messages if necessary)
                return .success
            }
            .responseJSON { response in
                debugPrint(response)
//                print(response.temporaryURL)
//                print(response.destinationURL)
                objAsset.downloadStatus = "1"
                NSManagedObjectContext.mr_default().mr_saveToPersistentStore(completion: nil)

                
                DispatchQueue.main.async {
                    //self.updateUI(objAsset: objAsset)
                    self.tblViewMain?.reloadData()
                }
//                self.cntDownloadFile += 1
//                self.startDownload()
 
        }
 
    }
    func updateUI(objAsset: Assets) {
        
        if ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("pdf")) == .orderedSame) {
            
        }
    }
    func getFilePath(objAsset: Assets) -> URL {
        let documentsPath1 = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        let logsPath = documentsPath1.appendingPathComponent("AssetFile")
        let filepath = logsPath?.appendingPathComponent(objAsset.fileName!)
        
        return filepath!
    }
}
extension HomeVC: UITableViewDataSource {
    public func numberOfSections(in tableView: UITableView) -> Int {
        
        if self.arrCampaign != nil {
            return self.arrCampaign.count
        }
        return 0
        
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: HomeVcTblCell = tableView.dequeueReusableCell(withIdentifier: "cellid") as! HomeVcTblCell
        cell.cvAssets.tag = indexPath.section
        cell.cvAssets.reloadData()
        print(indexPath.section)
        return cell
    }
    
    
}
extension HomeVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let obj = self.arrAssets[collectionView.tag]
        return obj.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: HomeVcCvAssetsCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cvcellid", for: indexPath) as! HomeVcCvAssetsCell
        let obj = self.arrAssets[collectionView.tag]
        let objAsset = obj[indexPath.row] as! Assets
        cell.lblAsset?.text = objAsset.fileName
        if objAsset.downloadStatus == "1" {
            if ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("pdf")) == .orderedSame) {
                cell.btnAsset?.setImage(UIImage.init(named: "imgPDF.png"), for: .normal)
            }
            else if ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("ppt")) == .orderedSame) {
                cell.btnAsset?.setImage(UIImage.init(named: "imgPowerPoint.png"), for: .normal)
            }
            else if ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("xls")) == .orderedSame) {
                cell.btnAsset?.setImage(UIImage.init(named: "imgExcel.png"), for: .normal)
            }
            else if ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("doc")) == .orderedSame) {
                cell.btnAsset?.setImage(UIImage.init(named: "imgWord.png"), for: .normal)
            }
            else if ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("jpg")) == .orderedSame) || ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("jpe")) == .orderedSame) || ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("jpeg")) == .orderedSame) || ((getFilePath(objAsset: objAsset).pathExtension.caseInsensitiveCompare("png")) == .orderedSame) {
                let url = self.getFilePath(objAsset: objAsset)
                print(url.absoluteString)
                print(url.path)
                cell.btnAsset?.setImage(UIImage.init(contentsOfFile: url.path), for: .normal)
            }
            else{
                cell.btnAsset?.setImage(nil, for: .normal)
            }
        }
        else{
            cell.btnAsset?.setImage(nil, for: .normal)
        }
        cell.pViewDownload?.progress = 0.0
        if let ipath = self.downloadInProgressCvCellIpath {
            if indexPath == ipath {
                self.cvcell = cell
                cell.pViewDownload?.progress = Float(self.downloadProgress)
                
            }
            
        }
        return cell
    }
}
