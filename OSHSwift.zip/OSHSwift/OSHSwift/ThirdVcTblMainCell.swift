//
//  ThirdVcTblMainCell.swift
//  OSHSwift
//
//  Created by Viral Narshana on 8/3/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit

class ThirdVcTblMainCell: UITableViewCell {

    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var viewWhite: UIView!
    @IBOutlet var segVc: UISegmentedControl!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setFilterData(_ arrFilterData:Array<String>) {
        
        //self.viewWhite.layoutIfNeeded()
        //self.lblTitle.text = ""
        var yInd,xInd:CGFloat
        yInd = 45.0
        xInd = 10.0
        for index in 0...arrFilterData.count-1 {
            let obj = arrFilterData[index]
            let button = UIButton(type: UIButtonType.custom)
            
            button.titleLabel?.font = UIFont(name: "Gill Sans", size: 17)
            button.setTitleColor(UIColor(red: 0/255.0, green: 116/255.0, blue: 189/255.0, alpha: 1), for: .normal)
            //button.backgroundColor = UIColor(red: 0/255.0, green: 116/255.0, blue: 189/255.0, alpha: 1)
            //button.backgroundColor = .blue
            button.layer.borderColor = UIColor(red: 0/255.0, green: 116/255.0, blue: 189/255.0, alpha: 1).cgColor
            button.layer.borderWidth = 1
            button.layer.cornerRadius = 3.0
            button.setTitle(obj, for: UIControlState())
            //button.addTarget(self, action: #selector(buttonAction), forControlEvents: .TouchUpInside)
            button.titleLabel?.adjustsFontSizeToFitWidth = true
            button.sizeToFit()
            
            if (CGFloat(xInd)+button.frame.size.width+5+5)>self.viewWhite.frame.size.width {
                yInd += 40
                xInd = 10
            }
            
            button.frame = CGRect(x: CGFloat(xInd), y: CGFloat(yInd), width: button.frame.size.width+15, height: 30)
            
            self.viewWhite.addSubview(button)
            
            xInd += button.frame.size.width+10
        }
        
    }
    
}
