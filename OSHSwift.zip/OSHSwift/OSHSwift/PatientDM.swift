//
//  PatientDM.swift
//  OSHSwift
//
//  Created by Viral Narshana on 7/20/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import Foundation

class PatientDM {
    var strName: String! = nil
    
/*    init(strName: String) {
        //self.strName = strName
    }
*/
    func assignVal(strName: String) {
        self.strName = strName
    }
}
