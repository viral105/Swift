//
//  Campaign.swift
//  OSHSwift
//
//  Created by Viral Narshana on 7/5/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit
import CoreData

class Campaign: NSManagedObject {
    @NSManaged var isDelete: String
    @NSManaged var campaignType: String
    @NSManaged var campaignCost: String
    @NSManaged var campaignCode: String
    @NSManaged var campaignEndDate: String
    @NSManaged var campaignStartDate: String
    @NSManaged var userId: String
    @NSManaged var campaignId: String
    @NSManaged var campaignName: String
    @NSManaged var campaignDesc: String
    @NSManaged var campaignParentId: String
    @NSManaged var companyId: String
}
