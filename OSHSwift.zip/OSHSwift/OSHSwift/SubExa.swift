//
//  SubExa.swift
//  OSHSwift
//
//  Created by Viral Narshana on 8/4/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import Foundation

struct SubExa {
//    let decrementer: Int
//    subscript(index: Int) -> Int {
//        return decrementer / index
//    }
    var no1 = 0.0, no2 = 0.0
    var length = 300.0, breadth = 150.0
    
    var middle: (Double, Double) {
        get{
            return (length / 2, breadth / 2)
        }set(axis) {
            no1 = axis.0 - (length / 2)
            no2 = axis.1 - (breadth / 2)
        }
    }
}
