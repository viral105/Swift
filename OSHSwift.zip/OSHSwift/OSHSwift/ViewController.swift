//
//  ViewController.swift
//  OSHSwift
//
//  Created by Viral Narshana on 7/5/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit
import Alamofire
import PassKit

struct ShippingMethod {
    let price: NSDecimalNumber
    let title: String
    let description: String
    
    init(price: NSDecimalNumber, title: String, description: String) {
        self.price = price
        self.title = title
        self.description = description
    }
    
    static let ShippingMethodOptions = [
        ShippingMethod(price: NSDecimalNumber(string: "5.00"), title: "Carrier Pigeon", description: "You'll get it someday."),
        ShippingMethod(price: NSDecimalNumber(string: "100.00"), title: "Racecar", description: "Vrrrroom! Get it by tomorrow!"),
        ShippingMethod(price: NSDecimalNumber(string: "9000000.00"), title: "Rocket Ship", description: "Look out your window!"),
        ]
}
class ViewController: UIViewController {

    let SupportedPaymentNetworks = [PKPaymentNetwork.visa, PKPaymentNetwork.masterCard, PKPaymentNetwork.amex]
    let ApplePaySwagMerchantID = "merchant.com.razeware.ApplePaySwag"
    var objCampaign: [Campaign]!
    override func viewDidLoad() {
        super.viewDidLoad()
        //let obj = Campaign.mr_createEntity()! as Campaign
        objCampaign = Campaign.mr_findAll() as! [Campaign]!
        print(objCampaign.count)
        // Do any additional setup after loading the view, typically from a nib.
        
        let documentsPath1 = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        let logsPath = documentsPath1.appendingPathComponent("AssetFile")
        print(logsPath?.absoluteString)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnLogin_Clicked(sender:Any) {
/*
        let parameters: Parameters = [
            "Email": "mdhapa@ismnet.com",
            "Password": "Mahesh@123",
            "DeviceID": "test123asffsda"
        ]
        Alamofire.request("http://api.omnisaleshub.com/api/Login", method: .post, parameters: parameters).responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            
            if let json = response.result.value {
                print("JSON: \(json)") // serialized json response
            }
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print("Data: \(utf8Text)") // original server data as UTF8 string
                self.performSegue(withIdentifier: "HomeVC", sender: nil)
            }
        }
*/
/*        let manager: Alamofire.SessionManager = {
            let serverTrustPolicies: [String: ServerTrustPolicy] = [
                "https://10.10.1.31": .disableEvaluation
            ]
            
            let configuration = URLSessionConfiguration.default
            //configuration.httpAdditionalHeaders = Alamofire.SessionManager.defaultHTTPHeaders
            
            return Alamofire.SessionManager(
                configuration: configuration,
                serverTrustPolicyManager: ServerTrustPolicyManager(policies: serverTrustPolicies)
            )
        }()

        let serverTrustPolicies: [String: ServerTrustPolicy] = [
            "https://10.10.1.31": .pinCertificates(
                certificates: ServerTrustPolicy.certificatesInBundle(),
                validateCertificateChain: true,
                validateHost: true
            ),
            "insecure.expired-apis.com": .DisableEvaluation
        ]
        
        let manager = Alamofire.SessionManager = (
            serverTrustPolicyManager: ServerTrustPolicyManager(policies: serverTrustPolicies)
        )
        let parameters: Parameters = [
            "X-Username": "NirajBusiness",
            "X-Password": "Niraj@1234"
        ]
        let headers: HTTPHeaders = [
            "X-Username": "NirajBusiness",
            "X-Password": "Niraj@1234",
            "Accept": "*"
        ]
        
        manager.request("https://10.10.1.31/OmniMDAPI/omnione/login/", method: .post, headers:headers).responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            
            if let json = response.result.value {
                print("JSON: \(json)") // serialized json response
            }
            if let json = response.result.error {
                print("JSON Err: \(json)") // serialized json response
            }
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print("Data: \(utf8Text)") // original server data as UTF8 string
                self.performSegue(withIdentifier: "HomeVC", sender: nil)
            }
        }
*/
        let parameters: Parameters = [
            "Email": "mdhapa@ismnet.com",
            "Password": "Mahesh@123",
            "DeviceID": "test123asffsda"
        ]
        let headers: HTTPHeaders = [
            "X-Username": "NirajBusiness",
            "X-Password": "Niraj@1234",
            "Content-Type": "application/json"
        ]
        Alamofire.request("http://10.10.1.151:6080/OmniMDAPI/omnione/login/", method: .post, headers: headers).responseJSON { response in
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            
            if let json = response.result.value {
                print("JSON: \(json)") // serialized json response
            }
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print("Data: \(utf8Text)") // original server data as UTF8 string
                self.performSegue(withIdentifier: "HomeVC", sender: nil)
            }
        }
    }

}

