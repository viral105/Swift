//
//  ThirdVc.swift
//  OSHSwift
//
//  Created by Viral Narshana on 8/3/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit

class ThirdVc: UIViewController {
    @IBOutlet var tblMain: UITableView?
    var arrDistance = ["Exact","2 KM","4 KM","6 KM","8 KM","10 KM"]
    override func viewDidLoad() {
        super.viewDidLoad()
        if let path = Bundle.main.path(forResource: "FilterData", ofType: "plist") {
            
            //If your plist contain root as Array
            if let array = NSArray(contentsOfFile: path) as? [[String: Any]] {
                
            }
            
            ////If your plist contain root as Dictionary
            if let dic = NSDictionary(contentsOfFile: path) {
                print(dic.allKeys)
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func findHeightOfRow() -> Float {
        var yInd,xInd:CGFloat
        yInd = 45.0
        xInd = 10.0
        
        for index in 0..<self.arrDistance.count {
            let obj = self.arrDistance[index]
            let width = obj.width(withConstraintedHeight: (self.view.frame.size.width)-20, font: UIFont(name: "Gill Sans", size: 17)!)
            //print("\(width) \((self.tblMain?.frame.size.width)!)")
            if (CGFloat(xInd)+width+5+5)>(self.view.frame.size.width-20) {
                print("not coming here")
                yInd += 40
                xInd = 10
            }
            xInd += width+25
        }
        print("findheight \(yInd) \(xInd) \(self.view.frame.size.width)")
        if yInd == 10 {
            return 50.0
        }
        else {
            
            return Float(yInd+40)
        }
    }
}
extension ThirdVc: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellid", for: indexPath) as! ThirdVcTblMainCell
            
            cell.setNeedsLayout()
            cell.layoutIfNeeded()
            cell.setFilterData(self.arrDistance)
            cell.lblTitle.text = "Distance"
            //cell.viewWhite.backgroundColor = .gray
            return cell
            
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellid2") as! ThirdVcTblMainCell
//            cell.setFilterData(self.arrDistance)
//            cell.lblTitle.text = "Distance"
//            cell.viewWhite.backgroundColor = .gray
//            let img = #imageLiteral(resourceName: "onestar_unsel").withRenderingMode(.alwaysOriginal)
//            cell.segVc.setImage(img, forSegmentAt: 3)
            return cell
            
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellid3")
            cell?.textLabel?.text = String(indexPath.row)
            return cell!
        }
    }
    @IBAction func btnStarClicked(sender: UIButton) {
        //let cell = self.tblMain?.cellForRow(at: IndexPath(row: 1, section: 0)) as! ThirdVcTblMainCell
        
        self.setImageOnSegVc(selIndex: sender.tag)
        
        //self.tblMain?.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .none)
    }
    func setImageOnSegVc(selIndex: Int) {
        for ind in 1 ..< selIndex+1 {
            let btn = self.view.viewWithTag(ind) as! UIButton
            btn.setImage(#imageLiteral(resourceName: "One"), for: .normal)
        }
        if selIndex != 5 {
            for index in selIndex+1...5 {
                let btn = self.view.viewWithTag(index) as! UIButton
                btn.setImage(#imageLiteral(resourceName: "onestar_unsel"), for: .normal)
            }
        }
    }
}
extension ThirdVc: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row {
        case 0:
            print("final height \(self.findHeightOfRow())")
            return CGFloat(self.findHeightOfRow())
            
        case 1:
            return 60
            
        default:
            return 44
        }
        
    }
}
extension String {
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSFontAttributeName: font], context: nil)
        
        return ceil(boundingBox.height)
    }
    
    func width(withConstraintedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSFontAttributeName: font], context: nil)
        
        return ceil(boundingBox.width)
    }
}
