//
//  HomeVcCvAssetsCell.swift
//  OSHSwift
//
//  Created by Viral Narshana on 7/6/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit

class HomeVcCvAssetsCell: UICollectionViewCell {
    @IBOutlet var btnAsset: UIButton?
    @IBOutlet var lblAsset: UILabel?
    @IBOutlet var pViewDownload: UIProgressView?
}
