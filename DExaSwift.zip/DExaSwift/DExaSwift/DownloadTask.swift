//
//  DownloadTask.swift
//  DExaSwift
//
//  Created by Viral Narshana on 7/26/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import Foundation

class DownloadTask {
    let fileTitle: String?
    let downloadSource: String?
    var downloadTask: URLSessionDownloadTask! = nil
    var taskResumeData: Data! = nil
    var downloadProgress: Double = 0.0
    var isDownloading = false
    var isDownloadComplete = false
    var taskIdentifier: Int = 0
    
    init(fileTitle: String, downloadSource: String) {
        self.fileTitle = fileTitle
        self.downloadSource = downloadSource
    }
    
}
