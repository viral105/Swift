//
//  ViewControllerTblCell.swift
//  DExaSwift
//
//  Created by Viral Narshana on 7/26/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit

protocol ViewControllerTblCellDelegate {
    func btnDownload_Clicked(cell: ViewControllerTblCell)
}


class ViewControllerTblCell: UITableViewCell {
    var delegate: ViewControllerTblCellDelegate?
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var btnDownload: UIButton!
    @IBOutlet var pviewDownload: UIProgressView!
    var objDownload: DownloadTask! = nil
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnDownloadTapped() {
        if !objDownload.isDownloadComplete {
            self.delegate?.btnDownload_Clicked(cell: self)
        }
        else {
            self.btnDownload.setTitle("Play", for: .normal)
        }
    }
}
