//
//  ViewController.swift
//  DExaSwift
//
//  Created by Viral Narshana on 7/26/17.
//  Copyright © 2017 ISM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tblMain: UITableView!
    var arrFileDownloadData = [DownloadTask]()
    var downloadsSession: URLSession!
    @IBOutlet var btnDownloadAll: UIButton!
    
    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    func localFilePath(for url: URL) -> URL {
        return documentsPath.appendingPathComponent(url.lastPathComponent)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.arrFileDownloadData = [DownloadTask(fileTitle: "AFNetworking", downloadSource: "https://github.com/AFNetworking/AFNetworking/archive/master.zip"), DownloadTask(fileTitle: "Big Buck Bunny", downloadSource: "http://www.sample-videos.com/video/mp4/720/big_buck_bunny_720p_5mb.mp4"), DownloadTask(fileTitle: "Big Buck 10mb", downloadSource: "http://www.sample-videos.com/video/mp4/720/big_buck_bunny_720p_10mb.mp4"), DownloadTask(fileTitle: "Big Buck 20mb", downloadSource: "http://www.sample-videos.com/video/mp4/720/big_buck_bunny_720p_20mb.mp4"), DownloadTask(fileTitle: "Big Buck 30mb", downloadSource: "http://www.sample-videos.com/video/mp4/720/big_buck_bunny_720p_30mb.mp4"), DownloadTask(fileTitle: "Big Buck 50mb", downloadSource: "http://www.sample-videos.com/video/mp4/720/big_buck_bunny_720p_50mb.mp4"), DownloadTask(fileTitle: "Big Buck 1mb", downloadSource: "http://www.sample-videos.com/video/mp4/480/big_buck_bunny_480p_1mb.mp4")]
        
        let configuration = URLSessionConfiguration.background(withIdentifier: "backgroundSession")
        //let configuration = URLSessionConfiguration.default
        self.downloadsSession = Foundation.URLSession(configuration: configuration, delegate: self, delegateQueue: OperationQueue.main)
        self.automaticallyAdjustsScrollViewInsets = false
        
        //self.btnDownloadAll.setImage(#imageLiteral(resourceName: "downloadAll"), for: .normal)
        
        self.btnDownloadAll.setBackgroundImage(#imageLiteral(resourceName: "downloadAll"), for: .normal)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    func getDownloadFileIndex(tId: Int) -> Int {
        for index in 0..<self.arrFileDownloadData.count {
            let obj = self.arrFileDownloadData[index]
            if obj.taskIdentifier == tId {
                return index
            }
        }
        return -1
    }
    @IBAction func btnDownloadAllTapped() {
        for index in 0..<self.arrFileDownloadData.count {
        let fdi = self.arrFileDownloadData[index]
        if (!fdi.isDownloading) {
            if (fdi.taskIdentifier != -1) {
                
                fdi.downloadTask = self.downloadsSession.downloadTask(with: URL(string: fdi.downloadSource!)!)
                
                fdi.taskIdentifier = fdi.downloadTask.taskIdentifier
                print("\(fdi.downloadSource ?? "d value") + \(fdi.taskIdentifier)")
                fdi.downloadTask.resume()
            }
        }
        fdi.isDownloading = !fdi.isDownloading
        }
    }
}
extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrFileDownloadData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ViewControllerTblCell = tableView.dequeueReusableCell(withIdentifier: "cellid") as! ViewControllerTblCell
        print(self.arrFileDownloadData[indexPath.row].fileTitle ?? "")
        cell.delegate = self
        cell.objDownload = self.arrFileDownloadData[indexPath.row]
        cell.lblTitle.text = self.arrFileDownloadData[indexPath.row].fileTitle
        if self.arrFileDownloadData[indexPath.row].isDownloadComplete {
            cell.btnDownload.setTitle("Play", for: .normal)
            cell.pviewDownload.isHidden = true
        }
        else{
            cell.btnDownload.setTitle("Download", for: .normal)
            cell.pviewDownload.isHidden = false
        }
        return cell
    }
}
extension ViewController: ViewControllerTblCellDelegate {
    func btnDownload_Clicked(cell: ViewControllerTblCell) {
        if let indexPath = tblMain.indexPath(for: cell) {
            let fdi = self.arrFileDownloadData[indexPath.row]
            if (!fdi.isDownloading) {
                if (fdi.taskIdentifier != -1) {
                    
                    fdi.downloadTask = self.downloadsSession.downloadTask(with: URL(string: fdi.downloadSource!)!)
                    
                    fdi.taskIdentifier = fdi.downloadTask.taskIdentifier
                    print("\(fdi.downloadSource ?? "d value") + \(fdi.taskIdentifier)")
                    fdi.downloadTask.resume()
                }
            }
            fdi.isDownloading = !fdi.isDownloading;
            
        }
    }
}
extension ViewController: URLSessionDelegate,URLSessionDownloadDelegate {
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        if totalBytesExpectedToWrite == NSURLSessionTransferSizeUnknown {
            
        }
        else{
            let index = getDownloadFileIndex(tId: downloadTask.taskIdentifier)
            if index != -1 {
                let objDTask = self.arrFileDownloadData[index]
                
                objDTask.downloadProgress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
                print(objDTask.downloadProgress)
                // 3
                //let totalSize = ByteCountFormatter.string(fromByteCount: totalBytesExpectedToWrite,                                                      countStyle: .file)
                // 4
                DispatchQueue.main.async {
                    if let trackCell = self.tblMain.cellForRow(at: IndexPath(row: index,
                                                                             section: 0)) as? ViewControllerTblCell {
                        trackCell.pviewDownload.progress = Float(objDTask.downloadProgress)
                    }
                }
            }
            
        }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        print("didCompleteWithError \(error.debugDescription)")
    }
    func urlSession(_ session: URLSession, didBecomeInvalidWithError error: Error?) {
        print("didBecomeInvalidWithError")
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        // 1
        let obj = self.getDownloadFileIndex(tId: downloadTask.taskIdentifier)
        let fdip = self.arrFileDownloadData[obj]
        
        let filepahtExt = downloadTask.originalRequest?.url?.lastPathComponent
        let destinationUrl = self.documentsPath.appendingPathComponent(filepahtExt!)
        //let download = fdip.downloadSource // downloadService.activeDownloads[sourceURL]
        
        // 2
        //let destinationURL = localFilePath(for: URL(string: fdip.downloadSource!)!)
        print("\(location) \(destinationUrl) \(fdip.downloadSource)")
        // 3
        let fileManager = FileManager.default
        /*let fileExist = fileManager.fileExists(atPath: destinationUrl.absoluteString)
        if fileExist {
            print("file exist")
        }
        else{
            print("file does not exist")
            do {
                try fileManager.copyItem(at: location, to: destinationUrl)
            }catch{
                print("Error for file write")
            }
            fdip.isDownloadComplete = true
        }
        */
        try? fileManager.removeItem(at: destinationUrl)
        do {
            try fileManager.copyItem(at: location, to: destinationUrl)
            fdip.isDownloadComplete = true
        } catch let error {
            print("Could not copy file to disk: \(error.localizedDescription)")
        }
        // 4
        
            DispatchQueue.main.async {
                if let trackCell = self.tblMain.cellForRow(at: IndexPath(row: obj,
                                                                         section: 0)) as? ViewControllerTblCell {
                self.tblMain.reloadRows(at: [self.tblMain.indexPath(for: trackCell)!], with: .none)
            }
        }
    }
}
